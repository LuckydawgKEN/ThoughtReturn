
  # Design Idea Companion Dashboard

  This is a code bundle for Design Idea Companion Dashboard. The original project is available at https://www.figma.com/design/n6UtTdX0Sg9hmBuxFLEE1j/Design-Idea-Companion-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  