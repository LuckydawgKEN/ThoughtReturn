import { createBrowserRouter } from "react-router";
import { LoginScreen } from "./screens/LoginScreen";
import { ChatScreen } from "./screens/ChatScreen";
import { ThoughtsScreen } from "./screens/ThoughtsScreen";
import { ThoughtDetailScreen } from "./screens/ThoughtDetailScreen";
import { SettingsScreen } from "./screens/SettingsScreen";
import { ProfileSettingsScreen } from "./screens/ProfileSettingsScreen";
import { PrivacySecurityScreen } from "./screens/PrivacySecurityScreen";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LoginScreen,
  },
  {
    path: "/chat",
    Component: ChatScreen,
  },
  {
    path: "/thoughts",
    Component: ThoughtsScreen,
  },
  {
    path: "/thought/:id",
    Component: ThoughtDetailScreen,
  },
  {
    path: "/settings",
    Component: SettingsScreen,
  },
  {
    path: "/settings/profile",
    Component: ProfileSettingsScreen,
  },
  {
    path: "/settings/privacy",
    Component: PrivacySecurityScreen,
  },
]);