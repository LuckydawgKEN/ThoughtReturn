import { useEffect } from "react";
import { RouterProvider } from "react-router";
import { ThemeProvider } from "./context/ThemeContext";
import { router } from "./routes";

export default function App() {
  useEffect(() => {
    document.title = "ThoughtReturn";
  }, []);

  return (
    <ThemeProvider>
      <RouterProvider router={router} />
    </ThemeProvider>
  );
}
