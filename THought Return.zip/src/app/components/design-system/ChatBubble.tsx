import { RefreshCw, User } from "lucide-react";
import { motion } from "motion/react";

interface ChatBubbleProps {
  role: "user" | "assistant";
  content: string;
  agent?: string;
}

export function ChatBubble({ role, content, agent }: ChatBubbleProps) {
  const isUser = role === "user";

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`flex gap-3 w-full ${isUser ? "justify-end" : "justify-start"}`}
    >
      {!isUser && (
        <div className="w-8 h-8 flex-shrink-0 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-sm">
          <RefreshCw className="w-4 h-4 text-white" />
        </div>
      )}

      <div className="flex flex-col gap-1 max-w-[60%]">
        <div
          className={`inline-block rounded-2xl px-4 py-3 ${
            isUser
              ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-sm"
              : "bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100"
          }`}
        >
          <p className="text-sm leading-relaxed">{content}</p>
        </div>
        {!isUser && agent && (
          <span className="text-xs text-gray-400 dark:text-gray-500 px-2">via {agent}</span>
        )}
      </div>

      {isUser && (
        <div className="w-8 h-8 flex-shrink-0 rounded-full bg-gray-300 dark:bg-gray-700 flex items-center justify-center">
          <User className="w-5 h-5 text-gray-600 dark:text-gray-300" />
        </div>
      )}
    </motion.div>
  );
}
