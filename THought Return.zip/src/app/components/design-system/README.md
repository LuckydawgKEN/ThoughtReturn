# ThoughtReturn Design System

A comprehensive mobile-first design system for the ThoughtReturn app.

## Components

### Button
- **Variants**: primary, secondary, ghost, outline
- **Sizes**: sm, md, lg
- **Features**: Gradient backgrounds, active states, full-width option

### Input
- **Features**: Label support, error states, dark mode
- **Style**: Rounded corners, focus states with ring

### Card
- **Features**: Hover animations, click interactions
- **Style**: Soft shadows, rounded corners

### ChatBubble
- **Types**: User and Assistant messages
- **Features**: Animated entrance, icon avatars, gradient backgrounds, AI agent labels

### ChatInput
- **Features**: Text input, send button, AI agent selector dropdown
- **Agents**: Claude, GPT, Gemini
- **Behavior**: Returns selected agent with each message submission
- **Style**: Rounded container with integrated controls, smooth animations

## Theme

### Colors
- **Primary Gradient**: Blue (600) to Purple (600)
- **Light Mode**: White backgrounds, gray text
- **Dark Mode**: Dark gray backgrounds, light text

### Typography
- Consistent font sizing
- Medium weight for headings
- Normal weight for body text

### Spacing
- Generous padding and margins
- Consistent gap between elements

## Usage

Import components from the design-system folder:
```tsx
import { Button } from "../components/design-system/Button";
import { Input } from "../components/design-system/Input";
```

Toggle theme:
```tsx
const { theme, toggleTheme } = useTheme();
```
