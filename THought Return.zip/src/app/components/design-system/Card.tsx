import { motion } from "motion/react";

interface CardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  hoverable?: boolean;
}

export function Card({ children, className = "", onClick, hoverable = false }: CardProps) {
  const Component = onClick || hoverable ? motion.div : "div";
  
  return (
    <Component
      {...(onClick || hoverable ? {
        whileHover: { scale: 1.02 },
        whileTap: onClick ? { scale: 0.98 } : {},
      } : {})}
      onClick={onClick}
      className={`bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm ${hoverable || onClick ? "cursor-pointer hover:shadow-md transition-shadow" : ""} ${className}`}
    >
      {children}
    </Component>
  );
}
