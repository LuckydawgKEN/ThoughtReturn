import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router";
import { Plus, Clock, Sparkles, Archive, MoreVertical, ArrowLeft } from "lucide-react";
import { Card } from "../components/design-system/Card";
import { motion, AnimatePresence } from "motion/react";

type IdeaStatus = "Active" | "Fading" | "Forgotten";
type CompletionStatus = "Completed" | "Abandoned" | null;

interface Thought {
  id: string;
  title: string;
  preview: string;
  timestamp: string;
  daysOld: number;
}

const getIdeaStatus = (daysOld: number): IdeaStatus => {
  if (daysOld <= 3) return "Active";
  if (daysOld <= 7) return "Fading";
  return "Forgotten";
};

const getStatusColor = (status: IdeaStatus) => {
  switch (status) {
    case "Active":
      return "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300";
    case "Fading":
      return "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300";
    case "Forgotten":
      return "bg-gray-100 dark:bg-gray-700/50 text-gray-500 dark:text-gray-400";
  }
};

const getCardOpacity = (status: IdeaStatus, completionStatus: CompletionStatus) => {
  if (completionStatus === "Abandoned") return "opacity-40";
  if (completionStatus === "Completed") return "opacity-100";

  switch (status) {
    case "Active":
      return "opacity-100";
    case "Fading":
      return "opacity-80";
    case "Forgotten":
      return "opacity-60";
  }
};

const getCompletionStatusColor = (status: CompletionStatus) => {
  if (status === "Completed") {
    return "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800";
  }
  if (status === "Abandoned") {
    return "bg-gray-100 dark:bg-gray-700/50 text-gray-500 dark:text-gray-400";
  }
  return "";
};

const getCardBackground = (completionStatus: CompletionStatus) => {
  if (completionStatus === "Completed") {
    return "bg-blue-50/50 dark:bg-blue-950/20";
  }
  return "";
};

const mockThoughts: Thought[] = [
  {
    id: "1",
    title: "AI-Powered Meal Planner",
    preview: "An app that generates personalized meal plans based on dietary preferences, budget, and available ingredients.",
    timestamp: "2 hours ago",
    daysOld: 0,
  },
  {
    id: "2",
    title: "Sustainable Fashion Marketplace",
    preview: "Platform connecting eco-conscious consumers with sustainable fashion brands.",
    timestamp: "Yesterday",
    daysOld: 1,
  },
  {
    id: "3",
    title: "Virtual Study Group Platform",
    preview: "Connecting students globally for collaborative learning with AI-powered recommendations.",
    timestamp: "3 days ago",
    daysOld: 3,
  },
  {
    id: "4",
    title: "Local Skills Exchange Network",
    preview: "Community platform where people can teach and learn skills from neighbors.",
    timestamp: "5 days ago",
    daysOld: 5,
  },
  {
    id: "5",
    title: "Mental Wellness Journal",
    preview: "Daily journaling app with AI insights and mood tracking.",
    timestamp: "1 week ago",
    daysOld: 7,
  },
  {
    id: "6",
    title: "Smart Home Energy Optimizer",
    preview: "IoT system that learns usage patterns to optimize energy consumption.",
    timestamp: "2 weeks ago",
    daysOld: 14,
  },
];

export function ThoughtsScreen() {
  const navigate = useNavigate();
  const [thoughts] = useState<Thought[]>(mockThoughts);
  const [searchQuery, setSearchQuery] = useState("");
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);
  const [completionStatuses, setCompletionStatuses] = useState<Record<string, CompletionStatus>>({});
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setOpenMenuId(null);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleMenuToggle = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setOpenMenuId(openMenuId === id ? null : id);
  };

  const handleStatusChange = (e: React.MouseEvent, id: string, status: CompletionStatus) => {
    e.stopPropagation();
    setCompletionStatuses((prev) => ({ ...prev, [id]: status }));
    setOpenMenuId(null);
  };

  const filteredThoughts = thoughts.filter(
    (thought) =>
      thought.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      thought.preview.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-4 sticky top-0 z-10 pt-[max(16px,env(safe-area-inset-top))]">
        <div className="flex items-center gap-2 mb-3">
          <button
            onClick={() => navigate("/chat")}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors -ml-2"
          >
            <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
          </button>
          <Archive className="w-5 h-5 text-gray-600 dark:text-gray-400" />
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">Vault</h1>
        </div>

        <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">
          {filteredThoughts.length} {filteredThoughts.length === 1 ? "idea" : "ideas"} stored
        </p>
      </header>

      {/* Ideas List */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {filteredThoughts.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center py-12">
            <div className="w-20 h-20 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mb-4">
              <Archive className="w-10 h-10 text-gray-400" />
            </div>
            <p className="text-gray-600 dark:text-gray-400 font-medium mb-1">Vault is empty</p>
            <p className="text-sm text-gray-500 dark:text-gray-500">
              Start saving ideas to see them here
            </p>
          </div>
        ) : (
          filteredThoughts.map((thought, index) => {
            const status = getIdeaStatus(thought.daysOld);
            const completionStatus = completionStatuses[thought.id];
            return (
              <motion.div
                key={thought.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={getCardOpacity(status, completionStatus)}
              >
                <Card
                  onClick={() => navigate(`/thought/${thought.id}`)}
                  hoverable
                  className={`p-4 border border-gray-200 dark:border-gray-700 ${getCardBackground(completionStatus)}`}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="font-semibold text-gray-900 dark:text-white flex-1">
                      {thought.title}
                    </h3>
                    <div className="flex items-center gap-2">
                      {completionStatus ? (
                        <span className={`text-xs px-2.5 py-1 rounded-full font-medium whitespace-nowrap ${getCompletionStatusColor(completionStatus)}`}>
                          {completionStatus}
                        </span>
                      ) : (
                        <span className={`text-xs px-2.5 py-1 rounded-full font-medium whitespace-nowrap ${getStatusColor(status)}`}>
                          {status}
                        </span>
                      )}
                      <div className="relative" ref={openMenuId === thought.id ? menuRef : null}>
                        <button
                          onClick={(e) => handleMenuToggle(e, thought.id)}
                          className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                        >
                          <MoreVertical className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                        </button>

                        <AnimatePresence>
                          {openMenuId === thought.id && (
                            <motion.div
                              initial={{ opacity: 0, scale: 0.95 }}
                              animate={{ opacity: 1, scale: 1 }}
                              exit={{ opacity: 0, scale: 0.95 }}
                              transition={{ duration: 0.1 }}
                              className="absolute right-0 top-full mt-1 bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden min-w-[130px] z-20"
                            >
                              <button
                                onClick={(e) => handleStatusChange(e, thought.id, "Completed")}
                                className="w-full px-4 py-2.5 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                              >
                                Complete
                              </button>
                              <button
                                onClick={(e) => handleStatusChange(e, thought.id, "Abandoned")}
                                className="w-full px-4 py-2.5 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                              >
                                Abandon
                              </button>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 mb-3">
                    {thought.preview}
                  </p>
                  <div className="flex items-center gap-1.5 text-xs text-gray-400 dark:text-gray-500">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{thought.timestamp}</span>
                  </div>
                </Card>
              </motion.div>
            );
          })
        )}
      </div>

      {/* Floating Action Button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => navigate("/chat")}
        className="fixed right-4 w-14 h-14 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full shadow-lg flex items-center justify-center z-20"
        style={{ bottom: `calc(20px + env(safe-area-inset-bottom))` }}
      >
        <Plus className="w-6 h-6" />
      </motion.button>

    </div>
  );
}
