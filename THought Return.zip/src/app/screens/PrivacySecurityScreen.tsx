import { useState } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Shield, Lock, Eye, EyeOff, Key } from "lucide-react";
import { Input } from "../components/design-system/Input";
import { Button } from "../components/design-system/Button";
import { Card } from "../components/design-system/Card";
import { motion } from "motion/react";

export function PrivacySecurityScreen() {
  const navigate = useNavigate();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPasswords, setShowPasswords] = useState(false);

  const handleChangePassword = () => {
    if (newPassword !== confirmPassword) {
      alert("Passwords don't match!");
      return;
    }
    alert("Password updated successfully!");
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  };

  return (
    <div className="h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button
          onClick={() => navigate("/settings")}
          className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-6 h-6 text-gray-600 dark:text-gray-300" />
        </button>
        <h1 className="text-xl font-bold text-gray-900 dark:text-white">Privacy & Security</h1>
      </header>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6">
        {/* Security Status */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="p-6 bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 border-blue-200 dark:border-blue-800">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-1">
                  Your Account is Secure
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Two-factor authentication is enabled and your password was last changed 30 days ago.
                </p>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Change Password */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3 px-1">
            CHANGE PASSWORD
          </h3>
          <Card className="p-6 space-y-4">
            <div className="relative">
              <Input
                label="Current Password"
                type={showPasswords ? "text" : "password"}
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Enter current password"
              />
            </div>
            <div className="relative">
              <Input
                label="New Password"
                type={showPasswords ? "text" : "password"}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Enter new password"
              />
            </div>
            <div className="relative">
              <Input
                label="Confirm New Password"
                type={showPasswords ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm new password"
              />
            </div>
            
            <button
              onClick={() => setShowPasswords(!showPasswords)}
              className="flex items-center gap-2 text-sm text-blue-600 dark:text-blue-400 hover:underline"
            >
              {showPasswords ? (
                <>
                  <EyeOff className="w-4 h-4" />
                  Hide passwords
                </>
              ) : (
                <>
                  <Eye className="w-4 h-4" />
                  Show passwords
                </>
              )}
            </button>

            <Button
              variant="primary"
              fullWidth
              onClick={handleChangePassword}
              disabled={!currentPassword || !newPassword || !confirmPassword}
              className="flex items-center justify-center gap-2"
            >
              <Key className="w-5 h-5" />
              Update Password
            </Button>
          </Card>
        </motion.div>

        {/* Privacy Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3 px-1">
            PRIVACY SETTINGS
          </h3>
          <Card className="divide-y divide-gray-200 dark:divide-gray-700">
            <div className="px-4 py-4">
              <label className="flex items-center justify-between cursor-pointer">
                <div>
                  <p className="text-gray-900 dark:text-white font-medium">
                    Two-Factor Authentication
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Add an extra layer of security
                  </p>
                </div>
                <input
                  type="checkbox"
                  defaultChecked
                  className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                />
              </label>
            </div>
            <div className="px-4 py-4">
              <label className="flex items-center justify-between cursor-pointer">
                <div>
                  <p className="text-gray-900 dark:text-white font-medium">
                    Data Collection
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Help improve the app with usage data
                  </p>
                </div>
                <input
                  type="checkbox"
                  defaultChecked
                  className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                />
              </label>
            </div>
            <div className="px-4 py-4">
              <label className="flex items-center justify-between cursor-pointer">
                <div>
                  <p className="text-gray-900 dark:text-white font-medium">
                    Share Analytics
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Share anonymous usage statistics
                  </p>
                </div>
                <input
                  type="checkbox"
                  className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                />
              </label>
            </div>
          </Card>
        </motion.div>

        {/* Data Management */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3 px-1">
            DATA MANAGEMENT
          </h3>
          <Card className="divide-y divide-gray-200 dark:divide-gray-700">
            <button className="w-full px-4 py-4 text-left hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
              <p className="text-gray-900 dark:text-white font-medium">
                Download Your Data
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Get a copy of your information
              </p>
            </button>
            <button className="w-full px-4 py-4 text-left hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors">
              <p className="text-red-600 dark:text-red-400 font-medium">
                Delete Account
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Permanently delete your account and data
              </p>
            </button>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
