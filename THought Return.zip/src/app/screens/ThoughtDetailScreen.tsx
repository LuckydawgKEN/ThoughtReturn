import { useState } from "react";
import { useNavigate, useParams } from "react-router";
import { ArrowLeft, Edit2, Trash2, MessageCircle, Share2, Clock } from "lucide-react";
import { Button } from "../components/design-system/Button";
import { motion } from "motion/react";

export function ThoughtDetailScreen() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState("AI-Powered Meal Planner");
  const [content, setContent] = useState(
    "An app that generates personalized meal plans based on dietary preferences, budget, and available ingredients. Could integrate with grocery delivery services.\n\nKey Features:\n- AI-powered recipe suggestions\n- Nutritional tracking\n- Budget optimization\n- Grocery list generation\n- Integration with delivery services\n\nTarget Audience:\n- Busy professionals\n- Health-conscious individuals\n- Families looking to save time and money\n\nPotential Challenges:\n- Recipe database curation\n- Dietary restriction handling\n- Grocery delivery API integrations"
  );

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this thought?")) {
      navigate("/thoughts");
    }
  };

  const handleContinueWithAI = () => {
    navigate("/chat", { state: { continueThought: { title, content } } });
  };

  return (
    <div className="h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <button
          onClick={() => navigate("/thoughts")}
          className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-6 h-6 text-gray-600 dark:text-gray-300" />
        </button>
        <div className="flex gap-2">
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <Edit2 className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          </button>
          <button
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <Share2 className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          </button>
          <button
            onClick={handleDelete}
            className="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
          >
            <Trash2 className="w-5 h-5 text-red-600 dark:text-red-400" />
          </button>
        </div>
      </header>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl mx-auto"
        >
          {/* Metadata */}
          <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mb-4">
            <Clock className="w-4 h-4" />
            <span>Created 2 hours ago</span>
            <span>•</span>
            <span className="px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-full text-xs font-medium">
              App Ideas
            </span>
          </div>

          {/* Title */}
          {isEditing ? (
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full text-3xl font-bold text-gray-900 dark:text-white mb-6 bg-transparent border-b-2 border-blue-500 focus:outline-none pb-2"
            />
          ) : (
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
              {title}
            </h1>
          )}

          {/* Content */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-6">
            {isEditing ? (
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full min-h-[400px] text-gray-700 dark:text-gray-300 bg-transparent focus:outline-none resize-none leading-relaxed"
              />
            ) : (
              <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap leading-relaxed">
                {content}
              </p>
            )}
          </div>

          {/* Actions */}
          <div className="mt-6 space-y-3">
            {isEditing ? (
              <Button
                variant="primary"
                fullWidth
                onClick={() => setIsEditing(false)}
              >
                Save Changes
              </Button>
            ) : (
              <Button
                variant="primary"
                fullWidth
                onClick={handleContinueWithAI}
                className="flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-5 h-5" />
                Continue with AI
              </Button>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
