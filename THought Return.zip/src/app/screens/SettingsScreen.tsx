import { useNavigate } from "react-router";
import { ArrowLeft, Moon, Sun, User, Bell, Lock, LogOut, HelpCircle, Info } from "lucide-react";
import { useTheme } from "../context/ThemeContext";
import { Card } from "../components/design-system/Card";
import { motion } from "motion/react";

export function SettingsScreen() {
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();

  const handleLogout = () => {
    if (confirm("Are you sure you want to log out?")) {
      navigate("/");
    }
  };

  return (
    <div className="h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3 flex items-center gap-3 sticky top-0 z-10 pt-[max(12px,env(safe-area-inset-top))]">
        <button
          onClick={() => navigate("/chat")}
          className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-6 h-6 text-gray-600 dark:text-gray-300" />
        </button>
        <h1 className="text-xl font-bold text-gray-900 dark:text-white">Settings</h1>
      </header>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6">
        {/* Profile Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                U
              </div>
              <div className="flex-1">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">User</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">user@example.com</p>
              </div>
              <button className="text-blue-600 dark:text-blue-400 text-sm font-medium hover:underline">
                Edit
              </button>
            </div>
          </Card>
        </motion.div>

        {/* Appearance */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3 px-1">
            APPEARANCE
          </h3>
          <Card className="p-4">
            <button
              onClick={toggleTheme}
              className="w-full flex items-center justify-between py-2"
            >
              <div className="flex items-center gap-3">
                {theme === "dark" ? (
                  <Moon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                ) : (
                  <Sun className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                )}
                <span className="text-gray-900 dark:text-white font-medium">
                  {theme === "dark" ? "Dark Mode" : "Light Mode"}
                </span>
              </div>
              <div className={`w-12 h-6 rounded-full transition-colors ${theme === "dark" ? "bg-blue-600" : "bg-gray-300"} relative`}>
                <motion.div
                  layout
                  className="w-5 h-5 bg-white rounded-full absolute top-0.5 shadow-sm"
                  style={{ left: theme === "dark" ? "26px" : "2px" }}
                />
              </div>
            </button>
          </Card>
        </motion.div>

        {/* Account Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3 px-1">
            ACCOUNT
          </h3>
          <Card className="divide-y divide-gray-200 dark:divide-gray-700">
            <button
              onClick={() => navigate("/settings/profile")}
              className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
            >
              <User className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              <span className="text-gray-900 dark:text-white font-medium">Profile Settings</span>
            </button>
            <button className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
              <Bell className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              <span className="text-gray-900 dark:text-white font-medium">Notifications</span>
            </button>
            <button
              onClick={() => navigate("/settings/privacy")}
              className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
            >
              <Lock className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              <span className="text-gray-900 dark:text-white font-medium">Privacy & Security</span>
            </button>
          </Card>
        </motion.div>

        {/* Support */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3 px-1">
            SUPPORT
          </h3>
          <Card className="divide-y divide-gray-200 dark:divide-gray-700">
            <button className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
              <HelpCircle className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              <span className="text-gray-900 dark:text-white font-medium">Help Center</span>
            </button>
            <button className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
              <Info className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              <span className="text-gray-900 dark:text-white font-medium">About</span>
            </button>
          </Card>
        </motion.div>

        {/* Logout */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <button
              onClick={handleLogout}
              className="w-full flex items-center justify-center gap-3 px-4 py-4 text-red-600 dark:text-red-400 font-medium hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors rounded-2xl"
            >
              <LogOut className="w-5 h-5" />
              <span>Log Out</span>
            </button>
          </Card>
        </motion.div>

        {/* App Version */}
        <p className="text-center text-sm text-gray-400 dark:text-gray-500 pb-4">
          ThoughtReturn v1.0.0
        </p>
      </div>
    </div>
  );
}